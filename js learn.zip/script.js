
var sineCanvas = document.getElementById('sine');
var ctx = sineCanvas.getContext("2d");
    increment = 0;
function sine(){
    
    y = 150 - Math.sin( increment ) * 120;
    increment += 0.01;
    ctx.fillStyle = "rgba(0,0,0,0.05)";
    ctx.fillRect(0, 0, sineCanvas.width, sineCanvas.height);
    
    ctx.fillStyle = "white";
    ctx.beginPath();
    ctx.arc( sineCanvas.width/2, y, 10, 0, Math.PI * 2);
    ctx.fill();    
}
window.setInterval( sine, 1000/30 );