
window.onload = function(){
    var sineCanvas = document.getElementById('sine');
    var ctx = sineCanvas.getContext("2d");       

    var frequency = 0.05;
    var phase = 30;
    var amplitude = 30;
    var color = "white";
    var shift = 1;
    var line_width = 4;
    //var outline = true; 
    var wavelength = sineCanvas.width/2;
    var origin = {x:0, y:sineCanvas.height/2};

    var point = function(x,y){
         //console.log('Inside point');
        var radius = line_width;    
        
        ctx.beginPath();
        ctx.fillStyle = "rgba(0,0,0,0.05)";
        //ctx.fillRect(0, 0, sineCanvas.width, sineCanvas.height);
        ctx.fillStyle = "rgba(255,255,255,1)";
        ctx.lineWidth = 10;
        ctx.arc(x,y,radius,0,2*Math.PI);
        //ctx.fillText(y,x,y);
        //console.log(y);
        ctx.fill();
    };

    var sine = function (){
         //console.log('Inside sine');
        for(var i = origin.x; i< (origin.x + wavelength); i++){
            //console.log('Inside sine for loop');
            var y = amplitude * Math.sin(frequency*(i+phase));
            point(i,origin.y+y);
            //y = amplitude * Math.sin(frequency*(i+(phase+100)));
            //point(i,origin.y+y);
            
        }
        //ctx.clearRect(0, 0, sineCanvas.width, sineCanvas.height);
    };
    
    var animate = function(){
        //console.log('Inside animate');        
        requestAnimationFrame(animate);
        ctx.clearRect(0, 0, sineCanvas.width, sineCanvas.height);
        phase += shift;        
        sine();       
    }
    
   animate();
    /*for(i=0;i<2;i++){
        console.log('Inside window for loop');
       setInterval(sine(),3000);             
       // setTimeout(ctx.clearRect(0, 0, sineCanvas.width, sineCanvas.height),30000);
        phase += shift;
    }*/

};