
window.onload = function(){
    var sineCanvas = document.getElementById('sine');
    var ctx = sineCanvas.getContext("2d");
        //increment = 0;
    /*function sine(){

        y = 150 - Math.sin( increment ) * 120;
        increment += 0.01;
        ctx.fillStyle = "rgba(0,0,0,0.09)";
        ctx.fillRect(0, 0, sineCanvas.width, sineCanvas.height);

        ctx.fillStyle = "white";
        ctx.beginPath();
        ctx.arc( sineCanvas.width/2, y, 10, 0, Math.PI * 2);
        ctx.fill();    
    }*/
    //window.setInterval( sine, 1000/30 );

    /*--------------------------------------------------*/

    var frequency = 0.05;
    var phase = 30;
    var amplitude = 50;
    var color = "White";
    var shift = 10;
    var line_width = 4;
    var outline = true; 
    var wavelength = sineCanvas.length;
    var origin = {x:0, y:sineCanvas.height/2};

    var point = function(x,y){
        var radius = line_width/2;
        ctx.beginPath();
        ctx.fillStyle = color;
        ctx.lineWidth = 2;
        ctx.arc(x,y,radius,0,2*Math.PI);
        ctx.fill();
    };

    var sine = function (){

        for(var i = origin.x; i< origin.x + wavelength ;i++){
            var y = amplitude * Math.sin(frequency*(i+phase));
            point(i,origin.y+y);
        }
    };
    
    var animate = function(){
        requestAnimationFrame(animate);
        ctx.clearRect(0, 0, sineCanvas.width, sineCanvas.height);
        phase += 12 + shift;
        
        sine();
    }
    
    animate();

};