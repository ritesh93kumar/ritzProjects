window.onload = function () {

    var sineCanvas = document.getElementById('sine');
    var ctx = sineCanvas.getContext("2d");

    var color = "rgba(255,255,255,0.5)";
    
    var line_width = 4;
    
    var origin = {
        x: 0,
        y: sineCanvas.height / 2
    };

    var wave = {
        amplitude: sineCanvas.height / 4, //default =30
        frequency: 0.05,
        phase: 0,
        shift: Math.PI/40,
        wavelength: sineCanvas.width / 2
    };

    var plotPoint = function (x, y) {

        var radius = line_width;

        ctx.beginPath();
        //ctx.fillStyle = "rgba(0,0,0,0.05)";
        //ctx.fillRect(0, 0, sineCanvas.width, sineCanvas.height);
        ctx.fillStyle = color;
        ctx.lineWidth = 10;
        ctx.arc(x, y, radius, 0, 2 * Math.PI);
        ctx.fill();
    };

    var sine = function () {
        for (var i = origin.x; i < (origin.x + wave.wavelength); i++) {
            
            //Sine Wave Equation: y(t) = A * sin( ωt+ Φ )
            var y = wave.amplitude * Math.sin(wave.frequency * i + wave.phase);
            
            plotPoint(i, origin.y - y);

            //y = amplitude * Math.sin(frequency*i+(phase+1000));
            //point(i,origin.y+y);            
        }
    };

    var animate = function () {
        //console.log('Inside animate');        
        requestAnimationFrame(animate);
        ctx.clearRect(0, 0, sineCanvas.width, sineCanvas.height);
        wave.phase += wave.shift;
        sine();
    }

    animate();
    /*for(i=0;i<2;i++){
        console.log('Inside window for loop');             
        setTimeout(ctx.clearRect(0, 0, sineCanvas.width, sineCanvas.height),30000);
        phase += shift;
    }*/

};
