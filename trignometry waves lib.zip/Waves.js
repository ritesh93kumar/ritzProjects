window.onload = function () {

    var canvas = document.getElementById('canvas');
    var ctx = canvas.getContext("2d");
    
    var line_width = 4;
    
    var toRadian = Math.PI / 180;
    var toDegree = 180 / Math.PI;

    var angle = 30;

    var angleInRadians = angle * toRadian;
    var angleInDegrees = angleInRadians * toDegree;
    
    var origin = {
        x: 0,
        y: canvas.height/2
    };
    
    var wave = {
        amplitude: canvas.height/4,
        frequency: 0.05,
        phase: 0,
        shift: Math.PI/40,
        wavelength: canvas.width/1.1,
        color: "rgba(255,255,255,0.5)"
    };

    var plotPoint = function (x, y, color) {

        var radius = line_width;

        ctx.beginPath();
        //ctx.fillStyle = "rgba(0,0,0,0.03)";
        //ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = color;
        ctx.lineWidth = 10;
        ctx.arc(x, y, radius, 0, 2 * Math.PI);
        ctx.fill();
    };

    var sine = function (sineWave) {
        
        sineWave.color = "rgba(255,0,0,0.5)"
        
        for (var i = origin.x; i < (origin.x + sineWave.wavelength); i++) {
            
            //Sine Wave Equation: y(t) = A * sin( ωt+ Φ )
            var y = sineWave.amplitude * Math.sin(sineWave.frequency * i + sineWave.phase);
            
            plotPoint(i, origin.y - y, sineWave.color);
                        
        }
    };
    
    var cos = function (cosWave) {
        
        cosWave.color = "rgba(0,255,0,0.5)"
        
        for (var i = origin.x; i < (origin.x + cosWave.wavelength); i++) {
            
            //Sine Wave Equation: y(t) = A * sin( ωt+ Φ )           

            y = cosWave.amplitude * Math.cos(cosWave.frequency * i + cosWave.phase);
            plotPoint(i,origin.y-y, cosWave.color); 
            
        }
    };
    
    var tan = function (tanWave) {
        
        tanWave.color = "rgba(0, 102, 255, 0.7)"
        
        
        for (var i = origin.x; i < (origin.x + tanWave.wavelength); i++) {
            
            //Sine Wave Equation: y(t) = A * sin( ωt+ Φ )
            y = tanWave.amplitude * Math.tan(tanWave.frequency * i + tanWave.phase);
            plotPoint(i,origin.y-y, tanWave.color);
            
        }
    };

    var animate = function () {      
        
        requestAnimationFrame(animate);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
                
        wave.amplitude = document.getElementById("amplitude").value;
        wave.frequency = document.getElementById("frequency").value;

        if(document.getElementById("freeze").checked == false)
            wave.phase += wave.shift;
        if(document.getElementById("sine").checked == true)
            sine(wave);
        if(document.getElementById("cos").checked == true)
            cos(wave);
        if(document.getElementById("tan").checked == true)
            tan(wave);
        
    }
    
    
    
    animate();
    
};
