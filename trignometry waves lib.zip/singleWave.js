window.onload  = function(){
    var canvas = document.getElementById("canvas");
    
    var init = function(){
        new drawWave({
            canvas:canvas,
            waveName:"sine",
            waveProperties:{}
        }).redraw();
    };    
    init();
}